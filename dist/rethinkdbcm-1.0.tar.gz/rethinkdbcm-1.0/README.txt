## RethinkDB context manager
