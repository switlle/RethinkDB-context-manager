from setuptools import setup

setup(
    name='rethinkdbcm',
    version='1.0',
    description='RethinkDB context manager',
    author='Mikhail Fyodorov',
    author_email='jwvsol@yandex.com',
    py_modules=['rethinkdbcm']
    )

