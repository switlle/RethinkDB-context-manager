# RethinkDB context manager

This is a RethinkDB context manager package. You can use
[RethinkDB-context-manager](https://github.com/gwvsol/RethinkDB-context-manager)
to write your content.
