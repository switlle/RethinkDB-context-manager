from setuptools import setup

setup(name='rethinkdbcm',
      version='0.1',
      description='RethinkDB context manager',
      long_description='RethinkDB context manager.',
      keywords='rethinkdb context manager',
      url='https://github.com/gwvsol/RethinkDB-context-manager',
      author='Mikhail Fyodorov',
      author_email='jwvsol@yandex.com',
      license='GNU General Public License v3.0',
      py_modules=['rethinkdbcm'],
      install_requires=['rethinkdb'],
      include_package_data=True,
      zip_safe=False)
